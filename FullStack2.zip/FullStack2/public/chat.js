const ws = new WebSocket('ws://localhost:3000');

const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendChat');

// פונקציה להוספת הודעה ל-UI
function addMessageToUI(sender, message) {
    const msgDiv = document.createElement('div');
    msgDiv.textContent = `${sender}: ${message}`;
    chatMessages.appendChild(msgDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight; // גלילה אוטומטית למטה
}

// שליחת הודעה
sendBtn.addEventListener('click', () => {
    const message = chatInput.value.trim();
    if (message !== '') {
        // מציג מיד בצ'אט של המשתמש עם "Me:"
        addMessageToUI('Me', message);

        // שולח לשרת
        ws.send(message);

        // מנקה את השדה
        chatInput.value = '';
    }
});

// קבלת הודעה מהשרת
ws.onmessage = (event) => {
    const message = event.data;
    // אם ההודעה היא שלנו, היא כבר הוצגה כ-"Me:", 
    // אז כאן נוסיף רק את ההודעות שהגיעו מאחרים
    addMessageToUI('Other', message);
};
