const express = require('express');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const PORT = 3000;

// רשימת תמונות
const images = [
    {
        src: 'https://www.misgeret.co.il/wht_Storage/Pics/artbyvered/Preview/473869-2132-30-06-24-SC-F01-400x546-90.jpg.webp?ver=0.0.10',
        name: 'Art',
        artist: 'Leonardo da Vinci',
        description: 'Description Lorem Ipsum 1'
    },
    {
        src: 'https://www.misgeret.co.il/wht_Storage/Pics/Van-Gogh/Preview/226244-957-08-04-14-SC-F01-400x329-90.jpg.webp?ver=0.0.10',
        name: 'Van Gogh',
        artist: 'Van Gogh',
        description: 'Description Lorem Ipsum 2'
    },
    {
        src: 'https://www.galleryonline.co.il/uploaded_files/768867b7bd8214bf80d82cccb70aebbd.jpg',
        name: 'Pigeon',
        artist: 'Sandro Botticelli',
        description: 'Description Lorem Ipsum 3'
    },
    {
        src: 'https://i.pinimg.com/736x/69/50/0a/69500a164caa2dc4d8aff9efd7cb4e4c.jpg',
        name: 'Beach',
        artist: 'Leonardo da Vinci',
        description: 'Description Lorem Ipsum 4'
    },
];

// הגדרת תיקיית public
app.use(express.static(path.join(__dirname, 'public')));

// API להחזרת רשימת תמונות
app.get('/api/images', (req, res) => {
    res.json(images);
});

// הפעלת השרת HTTP
const server = app.listen(PORT, () => {
    console.log(`HTTP server running on http://localhost:${PORT}`);
});

// WebSocket server
const wss = new WebSocket.Server({ server });

wss.on('connection', ws => {
    console.log('Client connected');

    ws.on('message', message => {
        // שליחת ההודעה לכל הלקוחות
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(message.toString());
            }
        });
    });

    ws.on('close', () => {
        console.log('Client disconnected');
    });
});
